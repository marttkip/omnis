	<section id="copyright" class="darkgrey_section with_top_border">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <p>&copy; Copyright <?php echo date('Y');?> - Chariot Photo Studio</p>
                </div>                
            </div>
        </div>
    </section>