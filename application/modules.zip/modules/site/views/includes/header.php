<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Omnis</title>
    <meta name="description" content="The ERP revolution">
    <meta name="keywords" content="ERP IT Website Medical">
    <meta name="HandheldFriendly" content="true">
    <meta name="MobileOptimized" content="320">
    <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9, user-scalable=no, target-densitydpi=device-dpi">
    <script type="text/javascript" src="<?php echo base_url().'assets/themes/omnis/'?>javascript/head.js"></script>
    <link rel="stylesheet" media="screen" href="<?php echo base_url().'assets/themes/omnis/'?>styles/screen.css">
    <link rel="stylesheet" media="print" href="<?php echo base_url().'assets/themes/omnis/'?>styles/print.css">
    <link rel="stylesheet" href="<?php echo base_url().'assets/themes/omnis/'?>styles/custom.css">
    <link rel="icon" type="image/x-icon" href="<?php echo base_url()?>assets/themes/omnis/img/favicon.png">
</head>