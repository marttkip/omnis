<div class="container pm-containerPadding80">
	<div class="row">
    	<div class="col-lg-12">
        	
            <h4 class="pm-author-column-title">About the Author</h4>
            
            <div class="row pm-containerPadding-top-30">
            	
                <div class="col-lg-3 col-md-3 col-sm-12">
                	
                    <div class="pm-author-bio-img-bg" style="background-image:url(img/news-post/avatar.jpg);">
                    	<div class="pm-single-news-post-avatar-icon">
                            <img width="33" height="41" src="img/news/post-icon.jpg" class="img-responsive" alt="icon">
                        </div>
                    </div>
                    
                </div>
                
                <div class="col-lg-9 col-md-9 col-sm-12">
                	<p class="pm-author-name">dr. john stanton</p>
                    <p class="pm-author-title">family physician</p>
                    <div class="pm-author-divider"></div>
                    <p class="pm-author-bio">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc fringilla erat nec tellus consectetur sodales. Vivamus quis est eget velit scelerisque condimentum sed non lorem. Morbi commodo id magna nec semper. Nullam pulvinar erat nisl, ac laoreet orci tempus iaculis. Vivamus nec tortor velit. Praesent a tortor nulla. Nullam pulvinar erat nisl, ac laoreet orci tempus iaculis.</p>
                </div>
                
            </div>
            
        </div>
    </div>
</div>